#include        <windows.h>


extern "C" int __declspec(dllexport) __stdcall (*Detoured_MessageBoxA)(DWORD hdlg, BYTE *test, BYTE *about, DWORD icont) = NULL;
extern "C" int __declspec(dllexport) __stdcall (*Detoured_GetModuleHandleA)(DWORD module) = NULL;

extern "C" int __declspec(dllexport) __stdcall HOOK_user32_MessageBoxA(DWORD hdlg, BYTE *text, BYTE *about, DWORD icont){
        int return_status;
        return_status=Detoured_MessageBoxA(hdlg, text, about, icont);
        return return_status;        
}

extern "C" int __declspec(dllexport) __stdcall HOOK_kernel32_GetModuleHandleA(DWORD module){
        return Detoured_GetModuleHandleA(module);
}


extern "C" void __declspec(dllexport) __stdcall hookmain(){
        Detoured_MessageBoxA(0, "hookmain called", "hookmain", 0);
}

bool WINAPI DllEntryPoint(DWORD imagebase, DWORD reason, DWORD reserved){
        GetModuleHandle(0);
        return  1;
}
