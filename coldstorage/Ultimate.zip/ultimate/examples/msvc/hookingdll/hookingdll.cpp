#include <windows.h>

extern "C" __declspec(dllexport) int (__stdcall *Detoured_MessageBoxA)(HWND hwnd, LPCTSTR text, LPCTSTR about, UINT uType) = NULL;
extern "C" __declspec(dllexport) HMODULE (__stdcall *Detoured_GetModuleHandleA)(LPCTSTR modulename) = NULL;

extern "C" int __declspec(dllexport) __stdcall HOOK_user32_MessageBoxA(HWND hwnd, LPCTSTR text, LPCTSTR about, UINT uType){
	return Detoured_MessageBoxA(hwnd, text, about, uType);
}

extern "C" HMODULE __declspec(dllexport) __stdcall HOOK_kernel32_GetModuleHandleA(LPCTSTR modulename){
	return Detoured_GetModuleHandleA(modulename);
}

//not needed __stdcall here becasue this is void w/o arguments :)
extern "C" void __declspec(dllexport) __stdcall hookmain(){
	Detoured_MessageBoxA((HWND)0, (LPCTSTR)"hookmain called", (LPCTSTR)"hookmain", 0);
}

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
					 )
{
    return TRUE;
}

