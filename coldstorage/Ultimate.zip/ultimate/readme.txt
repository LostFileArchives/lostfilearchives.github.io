                Ultimate Hooking Engine
                                (c) 2007 deroko of ARTeam
                                

Ultimate Hooking Engine is project started for my own needs, to be 
honest, I got tired of rewriting inline hooks everytime I need to
hook something.

This engine is very simple to use and is designed to be used by 
everyone that need to hook something, all that is required to hook
certain target is carfully crafted hooking dll with certain exports,
actually exports are used to locate API that you want to hook, there
are 3 export types that your dll may have:

1. prefixed HOOK
2. prefixed Detoured
3. hookmain (optional)

1. Whenever you want to hook some API you will put this kind of export:

   HOOK_kernel32_GetModuleHandleA
   HOOK_user32_MessageBoxA

   Also note that inline hook will point to this procedure so this procedure
   will have all of your code responsible for certain API.

2. To be able to call original API from your hook you should export also
   this variable (in C/C++ it will be function pointer):
   
   Note how variables are prefixed with "Detoured_"
   
   Detoured_GetModuleHandleA
   Detoured_MessageBoxA

   Here is one example from C/C++ code:
   
extern "C" __declspec(dllexport) HMODULE (__stdcall *Detoured_GetModuleHandleA)(LPCTSTR modulename) = NULL;

extern "C" HMODULE __declspec(dllexport) __stdcall HOOK_kernel32_GetModuleHandleA(LPCTSTR modulename){
	return Detoured_GetModuleHandleA(modulename);
}

  Note also that this is optional, if you don't need to call orignal proc,
  then you don't need this export.

  Note that when working with MSVC2005 it will always screw export name for  
  procedurs while function pointers are properly exported, so add this line
  to your .def file:

  HOOK_kernel32_GetModuleHandleA = _HOOK_kernel32_GetModuleHandleA@4
  Detoured_GetModuleHandleA   


3. hookmain

  hookmain is export which has this prototype:

  void __stdcall hookmain(); 

  This procedure will be called before program jumps to entrypoint of 
  target, here you may add some extra code, it isn't very useful and
  all initialization you may perfrom in DllEntry, but I leave this here
  just in case that you want to start your own tracer before code jmps
  to entrypoint. At least that's why I'm using it.
                                        
                                  
Examples for MSVC, Borland C and tasm you may find in examples folder,


Enjoy...

                                (c) 2007 deroko of ARTeam      